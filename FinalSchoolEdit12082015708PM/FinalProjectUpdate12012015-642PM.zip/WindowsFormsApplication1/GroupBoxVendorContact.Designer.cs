﻿namespace OrderEmployeedManagementWindowsNative
{
    partial class GroupBoxVendorContact
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InfogroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // CompanyNameTextBox
            // 
            this.CompanyNameTextBox.Size = new System.Drawing.Size(109, 22);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(13, 24);
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.Text = "Vendor";
            // 
            // CompanyNamelabel
            // 
            this.CompanyNamelabel.Size = new System.Drawing.Size(94, 16);
            this.CompanyNamelabel.Text = "Vendor Name";
            // 
            // ContactNotesTextBox
            // 
            this.ContactNotesTextBox.Text = "Delivery notes etc.";
            // 
            // ContactNoteslabel
            // 
            this.ContactNoteslabel.Size = new System.Drawing.Size(101, 16);
            this.ContactNoteslabel.Text = "Vendor Notes:";
            // 
            // InfogroupBox
            // 
            this.InfogroupBox.Size = new System.Drawing.Size(670, 238);
            // 
            // GroupBoxVendorContact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "GroupBoxVendorContact";
            this.Size = new System.Drawing.Size(888, 341);
            this.InfogroupBox.ResumeLayout(false);
            this.InfogroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
    }
}
